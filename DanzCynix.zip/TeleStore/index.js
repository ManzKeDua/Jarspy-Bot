const { Telegraf, session } = require('telegraf');
const fs = require('fs');
const path = require('path');
const config = require('./config.json');
const { Extra, Markup } = require('telegraf');
//const { createCanvas, loadImage } = require('canvas');
const bot = new Telegraf(config.token);
//const chalk = require('chalk');

if (!fs.existsSync('database.json')) {
    fs.writeFileSync('database.json', '[]');
}
let usersInGroup = []

bot.start((ctx) => {
    ctx.replyWithPhoto(
        config.thumbnailUrl,
        {
            caption: `Selamat datang, ${ctx.from.first_name}!
            
𝗛𝗮𝗹𝗹𝗼 𝗸𝗮𝗸, 𝗠𝗮𝗮𝗳 𝗝𝗶𝗸𝗮 𝗣𝗲𝗹𝗮𝘆𝗮𝗻𝗮𝗻 𝗕𝗼𝘁 𝗕𝗮𝗻𝘆𝗮𝗸 𝗞𝗲𝗸𝘂𝗿𝗮𝗻𝗴𝗮𝗻𝗻𝘆𝗮 𝗞𝗮𝗿𝗻𝗮 𝗕𝗼𝘁 𝗜𝗻𝗶 𝗠𝗮𝘀𝗶𝗵 𝗩𝗲𝗿𝘀𝗶 1.0.0 (𝗕𝗘𝗧𝗔)`,
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [
                        {text: 'YouTube', url: 'https://www.youtube.com'},
                        {text: 'WhatsApp', url: config.socialMedia.whatsapp},
                    ],
                    [
                        {text: 'Join Grup', url: 'https://t.me/+0hUvCxIHSiRlMDZl'}
                    ],
                    [
                        {text: 'OPEN MENU', callback_data: 'menu'}
                    ]
                ]
            }
        }
    );
});

//Menu Button
bot.action('menu', (ctx) => {
    ctx.deleteMessage().catch(() => {});
    ctx.replyWithPhoto(
        config.menu,
        {
            caption: `
   ╾────𝙇𝙞𝙨𝙩 • 𝙈𝙚𝙣𝙪────╼
  ╾───────────────╼
  ➣ /allmenu
  ➣ /topup
  ➣ /owner
  ➣ /produk
  ➣ /donasi
  ➣ /getids
  ╾───────────────╼

Bantu Bot Ini Terus Berkembang Dengan Cara Berdonasi 
`,
            reply_markup: {
                inline_keyboard: [
                    [
                        {text: 'WEB 👨‍💻', callback_data: 'web'},
                        {text: 'F TIKTOK🗃️', callback_data: 'ftt'}
                    ],
                    [
                        {text: 'Script Bot Here', callback_data: 'script'}
                    ]
                ]
            }
        }
    );
});

bot.action('web', (ctx) => {
    ctx.deleteMessage();
    const productPhotoPath = path.join(__dirname, 'cranz/tes2.jpg');
    if (fs.existsSync(productPhotoPath)) {
        ctx.replyWithPhoto(
            { source: fs.createReadStream(productPhotoPath) },
            {
                caption: 'Nama Produk: Produk A\nHarga: $10\nDeskripsi: Ini adalah deskripsi singkat tentang produk.',
                reply_markup: {
                    inline_keyboard: [
                        [
                            {text: 'Beli Sekarang', callback_data: 'buy'},
                            {text: '⬅️ Back', callback_data: 'menu'}
                        ]
                    ]
                }
            }
        ).then(() => ctx.deleteMessage());
    } else {
        ctx.reply('Maaf, foto produk tidak ditemukan.');
    }
});

bot.action('buy', (ctx) => {
    ctx.answerCbQuery('Anda telah memilih untuk membeli produk ini. Silakan lanjutkan ke proses pembayaran.');
});

bot.action('script', (ctx) => {
    ctx.deleteMessage().catch(() => {});
    const productPhotoPath = path.join(__dirname, 'cranz/tp.jpg');
    const audioPath = path.join(__dirname, 'cranz/audio.mp3');
    if (fs.existsSync(productPhotoPath) && fs.existsSync(audioPath)) {
        ctx.replyWithPhoto(
            { source: fs.createReadStream(productPhotoPath) },
            {
                caption: `Script Ini Agak Sulit Untuk Di Recode, Pastikan Kalian Membeli Ke Owner Aslinya Agar Dapat Pengajaran Untuk Setting Bot
           
 • Link Sc No Enc 80%   : https://mediafire.com
 • Link Sc No Enx 100% : IDR 15.000.00`,
                reply_markup: {
                    inline_keyboard: [
                        [
                            {text: 'Owner', callback_data: 'owner'},
                            {text: 'Buy', callback_data: 'buy'}
                        ],
                        [
                            {text: '⬅️ Back', callback_data: 'menu'}
                        ],
                    ]
                }
            }
        ).then(() => {
            return ctx.replyWithAudio(
                { source: fs.createReadStream(audioPath) }
            );
        }).then(() => ctx.deleteMessage()).catch((err) => console.log(err));
    } else {
        ctx.reply('Maaf, foto atau audio tidak ditemukan.').catch((err) => console.log(err));
    }
});
bot.action('owner', (ctx) => {
    // Ganti 'Your_Telegram_Contact' dengan kontak Telegram Anda yang sebenarnya
    ctx.reply('Berikut adalah kontak Telegram pemilik: @DaniGanz23 Dan @TwilightGanz');
});

//wellcome
bot.on('new_chat_members', (ctx) => {
    const newUser = ctx.message.new_chat_member;
    ctx.replyWithPhoto(
        'https://telegra.ph/file/f89890cc5f9f0f5098f22.jpg',
        {
            caption: `Halo ${newUser.first_name}, selamat datang di ${ctx.chat.title}! Jangan lupa baca deskripsi ya.`,
            parse_mode: 'Markdown',
            reply_markup: {
                    inline_keyboard: [
                        [
                            {text: 'Owner', callback_data: 'owner'},
                            {text: '⬅️ Back', callback_data: 'menu'}
                        ],
                        [
                            {text: '❤️Cari Jodoh❤️', callback_data: 'jodoh'},
                        ]
                    ]
                }
        }
    );
}); 

bot.action('jodoh', (ctx) => {
  // Cek jika pesan dikirim dari grup
  if (ctx.chat.type === 'group' || ctx.chat.type === 'supergroup') {
    // Jika ya, pilih pengguna acak dari grup
    if (usersInGroup.length > 0) {
      const randomUser = usersInGroup[Math.floor(Math.random() * usersInGroup.length)]
      // Tanggapi tombol dengan menandai pengguna acak
      ctx.reply(`@${ctx.from.username} dan @${randomUser.username}, mungkin Anda berdua adalah jodoh!`)
    } else {
      ctx.reply('Maaf, tidak ada pengguna lain dalam grup ini.')
    }
  }
})


//leave
bot.on('left_chat_member', (ctx) => {
    const leftUser = ctx.message.left_chat_member;
    bot.telegram.sendPhoto(
        leftUser.id,
        'https://telegra.ph/file/85d17018c69db96f618b7.jpg',
        {
            caption: `Jangan lupain kita ya, ${leftUser.first_name}. Nanti kalo mau join lagi, klik tombol di bawah ini.`,
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [
                        {text: 'Join Grup', url: 'https://t.me/+0hUvCxIHSiRlMDZl'}
                    ]
                ]
            }
        }
    );
});
//database
bot.on('message', async (ctx) => {
  if (ctx.message.text.includes('http://') || ctx.message.text.includes('https://')) {
    const admins = await ctx.getChatAdministrators();
    const userId = ctx.message.from.id;
    const isAdmin = admins.some(admin => admin.user.id === userId);

    if (!isAdmin) {
      ctx.deleteMessage();
      ctx.reply('Mohon maaf, hanya admin dan owner yang dapat mengirim link di grup ini.');
    }
  }
});

//console.log
bot.launch();